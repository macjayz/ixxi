import img1 from "../asset/img/one.jpg";
import img2 from "../asset/img/two.jpg";
import img3 from "../asset/img/three.jpg";
import img4 from "../asset/img/four.jpg";
import img6 from "../asset/img/six.jpg";
import img7 from "../asset/img/seven.jpg";
import img8 from "../asset/img/eight.jpg";
import img9 from "../asset/img/nine.jpg";
import img10 from "../asset/img/ten.jpg";
import img11 from "../asset/img/eleven.jpg";
import img12 from "../asset/img/twelve.png";
import img13 from "../asset/img/thirteen.jpg";
import img14 from "../asset/img/fourteen.jpg";
import img15 from "../asset/img/fifteen.jpg";
import img16 from "../asset/img/sixteen.png";
import img17 from "../asset/img/seventeen.jpg";
import img18 from "../asset/img/eighteen.jpg";
import img19 from "../asset/img/nineteen.jpg";
import img20 from "../asset/img/twenty.jpg";
import img21 from "../asset/img/twenty1.jpg";
import img22 from "../asset/img/twenty2.jpg";
import img23 from "../asset/img/twenty3.jpg";


import img24 from "../asset/img/1.jpg";
import img25 from "../asset/img/2.jpeg";
import img26 from "../asset/img/3.jpeg";
import img27 from "../asset/img/4.jpeg";
import img28 from "../asset/img/5.jpeg";
import img29 from "../asset/img/6.jpeg";
import img30 from "../asset/img/7.jpeg";
import img31 from "../asset/img/8.jpeg";
import img32 from "../asset/img/9.jpeg";
import img33 from "../asset/img/10.jpeg";
import img34 from "../asset/img/11.jpeg";
import img35 from "../asset/img/12.jpeg";
import img36 from "../asset/img/13.jpeg";
import img37 from "../asset/img/14.jpeg";
import img38 from "../asset/img/15.jpeg";
// trends
import img39 from "../asset/img/b1.png";
import img40 from "../asset/img/b2.png";
import img41 from "../asset/img/b3.png";
import img42 from "../asset/img/b4.png";
import img43 from "../asset/img/trends.png";
// social
import visa from "../asset/img/social/visa.webp";
import Facebook from "../asset/img/social/Facebook.png";
import electron from "../asset/img/social/electron.webp";
import mastercard from "../asset/img/social/mastercard.webp";
import express from "../asset/img/social/express.webp";
import paypal from "../asset/img/social/paypal.webp";
import instagram from "../asset/img/social/instagram.png";
import snapchat from "../asset/img/social/snapchat.png";


// men
import m1 from "../asset/img/men/a.jpeg";
import m2 from "../asset/img/men/a2.jpeg";
import m3 from "../asset/img/men/a3.jpeg";
import m4 from "../asset/img/men/a4.jpeg";
import m5 from "../asset/img/men/a5.jpeg";
import m6 from "../asset/img/men/a6.jpeg";
import m7 from "../asset/img/men/a7.jpeg";
import m8 from "../asset/img/men/a8.jpeg";
import m9 from "../asset/img/men/a10.jpeg";
import m10 from "../asset/img/men/a11.jpeg";

// kids

import k1 from "../asset/img/kids/k.jpeg";
import k2 from "../asset/img/kids/k2.jpeg";
import k3 from "../asset/img/kids/k3.jpeg";
import k4 from "../asset/img/kids/k4.jpeg";
import k5 from "../asset/img/kids/k5.jpeg";
import k6 from "../asset/img/kids/k6.jpeg";
import k7 from "../asset/img/kids/k7.jpeg";


// fitness
import f from "../asset/img/fitness/b.jpeg";
import f1 from "../asset/img/fitness/b2.jpeg";
import f2 from "../asset/img/fitness/b3.jpeg";
import f3 from "../asset/img/fitness/b4.jpeg";
import f4 from "../asset/img/fitness/b5.jpeg";
import f5 from "../asset/img/fitness/b6.jpeg";
import f6 from "../asset/img/fitness/b7.jpeg";
import f7 from "../asset/img/fitness/b8.jpeg";
import f8 from "../asset/img/fitness/b10.jpeg";


const Images = {
	img1,
	img2,
	img3,
	img4,
	img6,
	img7,
	img8,
	img9,
	img10,
	img11,
	img12,
	img13,
	img14,
	img15,
	img16,
	img17,
	img18,
	img19,
	img20,
	img21,
	img22,
	img23,
	img24,
	img25,
	img26,
	img27,
	img28,
	img29,
	img30,
	img31,
	img32,
	img33,
	img34,
	img35,
	img36,
	img37,
	img38,
	img39,
	img40,
	img41,
	img42,
	img43,
	instagram,
	Facebook,
	paypal,
	express,
	mastercard,
	snapchat,
	visa,
	electron,
	m1,
	m2,
	m3,
	m4,
	m5,
	m6,
	m7,
	m8,
	m9,
	m10,
	k1,
	k2,
	k3,
	k4,
	k5,
	k6,
	k7,
	f,
	f1,
	f2,
	f3,
	f4,
	f5,
	f6,
	f7,
	f8,
	
};
export default Images;
