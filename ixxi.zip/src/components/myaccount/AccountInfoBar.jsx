import React from "react";

export default function AccountInfoBar({ page }) {
  return (
    <section className="account__header">
      <h1>IXIX</h1>
      <h1>My Account</h1>
    </section>
  );
}
