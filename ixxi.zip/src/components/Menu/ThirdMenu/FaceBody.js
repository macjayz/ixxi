import React from 'react'

export default function FaceBody() {
  return (
    <div>FaceBody</div>
  )
}
