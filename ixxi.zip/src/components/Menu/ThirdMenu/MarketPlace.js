import React from 'react'

export default function MarketPlace() {
  return (
    <div>MarketPlace</div>
  )
}
