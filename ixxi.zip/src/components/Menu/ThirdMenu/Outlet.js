import React from 'react'

export default function Outlet() {
  return (
    <div>Outlet</div>
  )
}
