import React from 'react'

export default function Dresses() {
  return (
    <div>Dresses</div>
  )
}
