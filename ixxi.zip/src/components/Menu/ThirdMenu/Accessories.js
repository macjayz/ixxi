import React from 'react'

export default function Accessories() {
  return (
    <div>Accessories</div>
  )
}
