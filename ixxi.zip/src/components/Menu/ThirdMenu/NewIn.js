import React from 'react'

export default function NewIn() {
  return (
    <div>NewIn</div>
  )
}
