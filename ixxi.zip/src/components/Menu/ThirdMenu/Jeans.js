import React from 'react'

export default function Jeans() {
  return (
    <div>Jeans</div>
  )
}
