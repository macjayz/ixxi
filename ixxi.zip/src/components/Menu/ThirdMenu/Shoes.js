import React from 'react'

export default function Shoes() {
  return (
    <div>Shoes</div>
  )
}
