import React from 'react'

export default function Clothing() {
  return (
    <div>Clothing</div>
  )
}
