import React from 'react'

export default function PaymentCard() {
  return (
    <div>PaymentCard</div>
  )
}
